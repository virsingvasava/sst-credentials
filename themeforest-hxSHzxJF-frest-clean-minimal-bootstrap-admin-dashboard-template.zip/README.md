*************************************
Thank you for purchasing our template
*************************************

DOCUMENTATION
-------------
You can access the online documentation via below mentioned links:
HTML: https://www.pixinvent.com/demo/frest-clean-bootstrap-admin-dashboard-template/documentation/
Laravel: https://pixinvent.com/demo/frest-clean-bootstrap-admin-dashboard-template/documentation/documentation-laravel-folder-structure.html

SUPPORT REQUESTS
----------------
For your support requests, please visit https://pixinvent.ticksy.com/
Your support requests will be queued and can take up to 48 hours in
working days before answered.

UPDATING THE TEMPLATE
---------------------
You can use the GitHub repository to easily access the new features, bug fixes and update the template.
To request the access to repository, Please fill the form here: https://pixinvent.com/gitlab-access-provider-for-envato/

License Details
----------------
For details about license please check the license folder in the root directory. You can also read more about licensing here: http://themeforest.net/licenses